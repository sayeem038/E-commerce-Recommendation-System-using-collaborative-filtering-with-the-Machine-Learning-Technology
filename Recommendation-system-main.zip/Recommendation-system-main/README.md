# Recommendation-system
E-commerce-based Smart Recommendation System using element-by-element collaborative filtering following with the Machine Learning Technology
